// app/lib/data.ts
import { query } from './database';
import { formatCurrency } from './utils';
import {
  CustomerField,
  CustomersTableType,
  InvoiceForm,
  InvoicesTable,
  LatestInvoiceRaw,
  Revenue,
} from './definitions';

export async function fetchRevenue(): Promise<Revenue[]> {
  try {
    const data = await query<Revenue>('SELECT * FROM revenue');
    return data;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch revenue data.');
  }
}

export async function fetchLatestInvoices() {
  try {
    const data = await query<LatestInvoiceRaw>(`
      SELECT TOP 5 invoices.amount, customers.name, customers.image_url, customers.email, invoices.id
      FROM invoices
      JOIN customers ON invoices.customer_id = customers.id
      ORDER BY invoices.date DESC`);

    return data.map((invoice) => ({
      ...invoice,
      amount: formatCurrency(invoice.amount),
    }));
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch the latest invoices.');
  }
}

export async function fetchCardData() {
  try {
    // Use a single query for better performance (as suggested in the original comments)
    const data = await query<{
      invoice_count: number;
      customer_count: number;
      total_paid: number;
      total_pending: number;
    }>(`
      SELECT 
        (SELECT COUNT(*) FROM invoices) as invoice_count,
        (SELECT COUNT(*) FROM customers) as customer_count,
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) AS total_paid,
        SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) AS total_pending
      FROM invoices
    `);

    const result = data[0];

    return {
      numberOfInvoices: Number(result?.invoice_count ?? 0),
      numberOfCustomers: Number(result?.customer_count ?? 0),
      totalPaidInvoices: formatCurrency(result?.total_paid ?? 0),
      totalPendingInvoices: formatCurrency(result?.total_pending ?? 0),
    };
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch card data.');
  }
}

const ITEMS_PER_PAGE = 6;

export async function fetchFilteredInvoices(
  queryParam: string,
  currentPage: number,
): Promise<InvoicesTable[]> {
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;

  try {
    const data = await query<InvoicesTable>(`
      SELECT
        invoices.id,
        invoices.amount,
        invoices.date,
        invoices.status,
        customers.name,
        customers.email,
        customers.image_url
      FROM invoices
      JOIN customers ON invoices.customer_id = customers.id
      WHERE
        customers.name LIKE '%' + ? + '%' OR
        customers.email LIKE '%' + ? + '%' OR
        CAST(invoices.amount AS VARCHAR) LIKE '%' + ? + '%' OR
        CONVERT(VARCHAR, invoices.date, 23) LIKE '%' + ? + '%' OR
        invoices.status LIKE '%' + ? + '%'
      ORDER BY invoices.date DESC
      OFFSET ? ROWS FETCH NEXT ? ROWS ONLY`,
      [queryParam, queryParam, queryParam, queryParam, queryParam, offset, ITEMS_PER_PAGE]
    );

    return data;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch invoices.');
  }
}

export async function fetchInvoicesPages(queryParam: string): Promise<number> {
  try {
    const data = await query<{ count: number }>(`
      SELECT COUNT(*) as count
      FROM invoices
      JOIN customers ON invoices.customer_id = customers.id
      WHERE
        customers.name LIKE '%' + ? + '%' OR
        customers.email LIKE '%' + ? + '%' OR
        CAST(invoices.amount AS VARCHAR) LIKE '%' + ? + '%' OR
        CONVERT(VARCHAR, invoices.date, 23) LIKE '%' + ? + '%' OR
        invoices.status LIKE '%' + ? + '%'`,
      [queryParam, queryParam, queryParam, queryParam, queryParam]
    );

    return Math.ceil(Number(data[0]?.count) / ITEMS_PER_PAGE);
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch total number of invoices.');
  }
}

export async function fetchInvoiceById(id: string): Promise<InvoiceForm | null> {
  try {
    const data = await query<InvoiceForm>(`
      SELECT
        id,
        customer_id,
        amount,
        status
      FROM invoices
      WHERE id = ?`,
      [id]
    );

    return data.length > 0 ? {
      ...data[0],
      amount: data[0].amount / 100 // Convert amount from cents to dollars
    } : null;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch invoice.');
  }
}

export async function fetchCustomers(): Promise<CustomerField[]> {
  try {
    const data = await query<CustomerField>(`
      SELECT
        id,
        name
      FROM customers
      ORDER BY name ASC`
    );

    return data;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch all customers.');
  }
}

export async function fetchFilteredCustomers(queryParam: string) {
  try {
    const data = await query<CustomersTableType>(`
      SELECT
        customers.id,
        customers.name,
        customers.email,
        customers.image_url,
        COUNT(invoices.id) AS total_invoices,
        SUM(CASE WHEN invoices.status = 'pending' THEN invoices.amount ELSE 0 END) AS total_pending,
        SUM(CASE WHEN invoices.status = 'paid' THEN invoices.amount ELSE 0 END) AS total_paid
      FROM customers
      LEFT JOIN invoices ON customers.id = invoices.customer_id
      WHERE
        customers.name LIKE '%' + ? + '%' OR
        customers.email LIKE '%' + ? + '%'
      GROUP BY customers.id, customers.name, customers.email, customers.image_url
      ORDER BY customers.name ASC`,
      [queryParam, queryParam]
    );

    return data.map((customer) => ({
      ...customer,
      total_pending: formatCurrency(customer.total_pending),
      total_paid: formatCurrency(customer.total_paid),
    }));
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch customer table.');
  }
}